#include <stdio.h>
#include<mpi.h>
#include<time.h>
int main(int argc,char *argv[])
{
clock_t start = clock();
  clock_t stop = clock();
double elapsed = (double)(stop-start)*1000/ CLOCKS_PER_SEC;

int a, som = 0,rank,size, tab[5],b,som_p = 0;
MPI_Status status;
MPI_Init(&argc,&argv);
MPI_Comm_rank(MPI_COMM_WORLD,&rank);
MPI_Comm_size(MPI_COMM_WORLD,&size);
if(rank==0){
    for(int i =0 ; i<5; i++){
        printf("Entrez l'entier Numero %d\n",i);
        scanf("%d",&tab[i]);

    }
    printf("Envoyer des données vers les noeuds esclaves......\n");
    MPI_Send(&tab[0],1,MPI_INT,1,1,MPI_COMM_WORLD);
    MPI_Send(&tab[1],1,MPI_INT,1,1,MPI_COMM_WORLD);
    MPI_Send(&tab[2],1,MPI_INT,1,1,MPI_COMM_WORLD);
    MPI_Send(&tab[3],1,MPI_INT,1,1,MPI_COMM_WORLD);
    printf("Reception des données des noeuds esclaves.....\n");
    MPI_Recv(&a,1,MPI_INT,1,1,MPI_COMM_WORLD,&status);
    som +=a;
    MPI_Recv(&a,1,MPI_INT,2,1,MPI_COMM_WORLD,&status);
    som +=a;
    printf("La somme obteune est :%d\n ",som+tab[4]);
   

}
else{
    if(rank < 3){
        //printf("Envoie des données du maitre par le noeud %d......\n",rank);
        MPI_Recv(&a,1,MPI_INT,0,1,MPI_COMM_WORLD,&status);
        som_p +=a;
         MPI_Recv(&a,1,MPI_INT,0,1,MPI_COMM_WORLD,&status);
         som_p +=a;
          //printf("Envoie des données vers le maitre par le noeud %d......\n",rank);
         MPI_Send(&som_p,1,MPI_INT,0,1,MPI_COMM_WORLD);

    }
}
printf("le temps sequentielle est de| in ms:%f\n", elapsed);
MPI_Finalize();
return 0;

}